<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class CartMate_Emailer {

    public static function send_recovery_email( $email, $cart_data ) {
        $subject = get_option( 'cartmate_email_subject', 'You left something in your cart!' );
        $message = get_option( 'cartmate_email_body',
            "Hi there,\n\nLooks like you didn’t finish your order.\nClick below to return to your cart:\n\n" . site_url( '/cart/' )
        );

        $headers = [ 'From: Hustlemate <noreply@hustlemate.au>' ];
        wp_mail( $email, $subject, $message, $headers );
    }
}

