<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class CartMate_Cron {

    public function __construct() {
        // Schedule the event
        add_action( 'wp', [ $this, 'schedule_cron' ] );
        // Hook our job
        add_action( 'cartmate_check_abandoned_carts', [ $this, 'process_abandoned_carts' ] );
    }

    public function schedule_cron() {
        if ( ! wp_next_scheduled( 'cartmate_check_abandoned_carts' ) ) {
            wp_schedule_event( time(), 'half_hour', 'cartmate_check_abandoned_carts' );
        }
    }

    public function process_abandoned_carts() {
        global $wpdb;
        $table = $wpdb->prefix . 'cartmate_carts';
        $delay = get_option( 'cartmate_email_delay', 3 ); // hours

        $threshold = gmdate( 'Y-m-d H:i:s', strtotime( "-{$delay} hours" ) );
        $carts = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM $table WHERE status = 'abandoned' AND last_updated < %s", $threshold
        ) );

        foreach ( $carts as $cart ) {
            if ( ! empty( $cart->email ) ) {
                CartMate_Emailer::send_recovery_email( $cart->email, maybe_unserialize( $cart->cart_contents ) );
                $wpdb->update( $table, [ 'status' => 'emailed' ], [ 'id' => $cart->id ] );
            }
        }
    }
}

// Custom schedule interval
add_filter( 'cron_schedules', function( $schedules ) {
    $schedules['half_hour'] = [ 'interval' => 1800, 'display' => 'Every 30 Minutes' ];
    return $schedules;
});
