<?php
/**
 * CartMate DB installer + schema locking.
 *
 * Authoritative tables:
 *  - {$wpdb->prefix}cartmate_carts
 *  - {$wpdb->prefix}cartmate_email_sequences
 *
 * Legacy table (not used by core flow):
 *  - {$wpdb->prefix}cartmate_abandoned_carts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'CartMate_DB' ) ) :

class CartMate_DB {

    /**
     * Increment when schema changes.
     */
    const DB_VERSION = '1.3.0';

    /**
     * Option key storing installed schema version.
     */
    const DB_VERSION_OPTION = 'cartmate_db_version';

    /**
     * Install / upgrade schema.
     */
    public static function install() {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset_collate = $wpdb->get_charset_collate();

        $carts_table = $wpdb->prefix . 'cartmate_carts';
        $seq_table   = $wpdb->prefix . 'cartmate_email_sequences';

        // -------------------------------
        // Table: cartmate_carts (locked)
        // -------------------------------
        $sql_carts = "CREATE TABLE {$carts_table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            contact_email VARCHAR(190) NOT NULL DEFAULT '',
            contact_phone VARCHAR(50) NOT NULL DEFAULT '',
            contact_name VARCHAR(190) NOT NULL DEFAULT '',
            email_opt_in TINYINT(1) NOT NULL DEFAULT 0,
            sms_opt_in TINYINT(1) NOT NULL DEFAULT 0,
            abandoned_at BIGINT(20) NOT NULL DEFAULT 0,
            email_first_sent_at BIGINT(20) NULL DEFAULT NULL,
            sms_first_sent_at BIGINT(20) NULL DEFAULT NULL,
            recovered TINYINT(1) NOT NULL DEFAULT 0,
            created_at BIGINT(20) NOT NULL DEFAULT 0,
            updated_at BIGINT(20) NOT NULL DEFAULT 0,
            email_step_sent INT(11) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            KEY idx_email (contact_email),
            KEY idx_phone (contact_phone),
            KEY idx_abandoned (abandoned_at),
            KEY idx_recovered (recovered),
            KEY idx_email_step (email_step_sent)
        ) {$charset_collate};";

        // ----------------------------------------
        // Table: cartmate_email_sequences (locked)
        // ----------------------------------------
        $sql_seq = "CREATE TABLE {$seq_table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            enabled TINYINT(1) NOT NULL DEFAULT 1,
            delay_days INT(11) NOT NULL DEFAULT 1,
            subject VARCHAR(255) NOT NULL DEFAULT '',
            body LONGTEXT NOT NULL,
            sort_order INT(11) NOT NULL DEFAULT 0,
            created_at BIGINT(20) NOT NULL DEFAULT 0,
            updated_at BIGINT(20) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            KEY idx_enabled (enabled),
            KEY idx_sort (sort_order),
            KEY idx_delay (delay_days)
        ) {$charset_collate};";

        // dbDelta is idempotent and will add missing columns/keys.
        dbDelta( $sql_carts );
        dbDelta( $sql_seq );

        // Safety migrations (covers environments where dbDelta misses alterations).
        self::migrate_column_if_missing( $carts_table, 'email_step_sent', "ALTER TABLE {$carts_table} ADD COLUMN email_step_sent INT(11) NOT NULL DEFAULT 0" );
        self::migrate_column_if_missing( $seq_table,   'sort_order',     "ALTER TABLE {$seq_table} ADD COLUMN sort_order INT(11) NOT NULL DEFAULT 0" );
        self::migrate_column_if_missing( $seq_table,   'enabled',        "ALTER TABLE {$seq_table} ADD COLUMN enabled TINYINT(1) NOT NULL DEFAULT 1" );
        self::migrate_column_if_missing( $seq_table,   'delay_days',     "ALTER TABLE {$seq_table} ADD COLUMN delay_days INT(11) NOT NULL DEFAULT 1" );
        self::migrate_column_if_missing( $seq_table,   'subject',        "ALTER TABLE {$seq_table} ADD COLUMN subject VARCHAR(255) NOT NULL DEFAULT ''" );
        self::migrate_column_if_missing( $seq_table,   'body',           "ALTER TABLE {$seq_table} ADD COLUMN body LONGTEXT NOT NULL" );
        self::migrate_column_if_missing( $seq_table,   'created_at',     "ALTER TABLE {$seq_table} ADD COLUMN created_at BIGINT(20) NOT NULL DEFAULT 0" );
        self::migrate_column_if_missing( $seq_table,   'updated_at',     "ALTER TABLE {$seq_table} ADD COLUMN updated_at BIGINT(20) NOT NULL DEFAULT 0" );

        // Ensure indexes exist.
        self::maybe_add_index( $seq_table,   'idx_sort',       "ALTER TABLE {$seq_table} ADD INDEX idx_sort (sort_order)" );
        self::maybe_add_index( $seq_table,   'idx_enabled',    "ALTER TABLE {$seq_table} ADD INDEX idx_enabled (enabled)" );
        self::maybe_add_index( $seq_table,   'idx_delay',      "ALTER TABLE {$seq_table} ADD INDEX idx_delay (delay_days)" );
        self::maybe_add_index( $carts_table, 'idx_email_step', "ALTER TABLE {$carts_table} ADD INDEX idx_email_step (email_step_sent)" );

        // Seed defaults if empty.
        self::seed_default_sequences_if_empty( $seq_table );

        update_option( self::DB_VERSION_OPTION, self::DB_VERSION );
    }

    /**
     * Upgrade runner.
     * Call on plugins_loaded; safe to run every request.
     */
    public static function maybe_upgrade() {
        $installed = get_option( self::DB_VERSION_OPTION, '' );
        if ( $installed !== self::DB_VERSION ) {
            self::install();
        }
    }

    private static function migrate_column_if_missing( $table, $column, $sql ) {
        global $wpdb;

        $exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COLUMN_NAME
                 FROM INFORMATION_SCHEMA.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE()
                   AND TABLE_NAME = %s
                   AND COLUMN_NAME = %s",
                $table,
                $column
            )
        );

        if ( empty( $exists ) ) {
            $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        }
    }

    private static function maybe_add_index( $table, $index_name, $sql ) {
        global $wpdb;

        $found = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT INDEX_NAME
                 FROM INFORMATION_SCHEMA.STATISTICS
                 WHERE TABLE_SCHEMA = DATABASE()
                   AND TABLE_NAME = %s
                   AND INDEX_NAME = %s
                 LIMIT 1",
                $table,
                $index_name
            )
        );

        if ( empty( $found ) ) {
            $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        }
    }

    private static function seed_default_sequences_if_empty( $seq_table ) {
        global $wpdb;

        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$seq_table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        if ( $count > 0 ) {
            return;
        }

        $now = time();

        // These are just starter templates; user can edit/delete/disable in UI.
        $defaults = array(
            array(
                'enabled'    => 1,
                'delay_days' => 1,
                'subject'    => 'Quick reminder: your cart is still waiting at {site_name}',
                'body'       => "Hi {name},\n\nJust checking in — your cart is still saved.\n\n{cart_url}\n\n– {site_name}",
                'sort_order' => 10,
            ),
            array(
                'enabled'    => 1,
                'delay_days' => 2,
                'subject'    => 'Need a hand? Your cart is still available at {site_name}',
                'body'       => "Hi {name},\n\nIf you had any issues checking out, your cart is still here:\n\n{cart_url}\n\n– {site_name}",
                'sort_order' => 20,
            ),
            array(
                'enabled'    => 1,
                'delay_days' => 4,
                'subject'    => 'A friendly nudge — your cart is still saved at {site_name}',
                'body'       => "Hi {name},\n\nYour items are still in your cart. If you want to finish up:\n\n{cart_url}\n\n– {site_name}",
                'sort_order' => 30,
            ),
            array(
                'enabled'    => 1,
                'delay_days' => 6,
                'subject'    => 'Last chance to complete your order at {site_name}',
                'body'       => "Hi {name},\n\nFinal reminder — your cart is still saved for a little longer:\n\n{cart_url}\n\n– {site_name}",
                'sort_order' => 40,
            ),
            array(
                'enabled'    => 0,
                'delay_days' => 7,
                'subject'    => 'Optional: Want 10% off? Complete your order at {site_name}',
                'body'       => "Hi {name},\n\nOptional template (disable/enable as needed):\n\n{cart_url}\n\n– {site_name}",
                'sort_order' => 50,
            ),
        );

        foreach ( $defaults as $row ) {
            $wpdb->insert(
                $seq_table,
                array(
                    'enabled'    => (int) $row['enabled'],
                    'delay_days' => (int) $row['delay_days'],
                    'subject'    => $row['subject'],
                    'body'       => $row['body'],
                    'sort_order' => (int) $row['sort_order'],
                    'created_at' => $now,
                    'updated_at' => $now,
                ),
                array( '%d', '%d', '%s', '%s', '%d', '%d', '%d' )
            );
        }
    }
}

endif;
