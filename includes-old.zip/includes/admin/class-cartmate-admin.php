<?php
/**
 * Admin UI for WPCartMate.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'CartMate_Admin' ) ) :

class CartMate_Admin {

    protected static $instance = null;

    public static function init() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_menu', array( $this, 'register_menu' ) );
        add_action( 'admin_init', array( $this, 'handle_form_submission' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
    }

    public function register_menu() {
        $cap = 'manage_woocommerce';

        add_menu_page(
            __( 'WPCartMate', 'cartmate' ),
            __( 'WPCartMate', 'cartmate' ),
            $cap,
            'cartmate',
            array( $this, 'render_settings_page' ),
            'dashicons-cart',
            56
        );

        add_submenu_page( 'cartmate', __( 'Dashboard', 'cartmate' ), __( 'Dashboard', 'cartmate' ), $cap, 'cartmate', array( $this, 'render_settings_page' ) );
        add_submenu_page( 'cartmate', __( 'Email Reminder', 'cartmate' ), __( 'Email Reminder', 'cartmate' ), $cap, 'cartmate-email', array( $this, 'render_settings_page' ) );

        // NEW: Scheduled follow-ups page (DB-driven)
        add_submenu_page( 'cartmate', __( 'Scheduled Email Followups', 'cartmate' ), __( 'Scheduled Email Followups', 'cartmate' ), $cap, 'cartmate-email-followups', array( $this, 'render_settings_page' ) );

        add_submenu_page( 'cartmate', __( 'SMS Settings', 'cartmate' ), __( 'SMS Settings', 'cartmate' ), $cap, 'cartmate-sms', array( $this, 'render_settings_page' ) );
        add_submenu_page( 'cartmate', __( 'Admin Notifications', 'cartmate' ), __( 'Admin Notifications', 'cartmate' ), $cap, 'cartmate-notifications', array( $this, 'render_settings_page' ) );
        add_submenu_page( 'cartmate', __( 'License & Upgrades', 'cartmate' ), __( 'License & Upgrades', 'cartmate' ), $cap, 'cartmate-license', array( $this, 'render_settings_page' ) );
        add_submenu_page( 'cartmate', __( 'System Status', 'cartmate' ), __( 'System Status', 'cartmate' ), $cap, 'cartmate-status', array( $this, 'render_settings_page' ) );
    }

    public function enqueue_assets( $hook ) {
        if ( ! isset( $_GET['page'] ) ) return;

        $page = sanitize_text_field( wp_unslash( $_GET['page'] ) );
        if ( strpos( $page, 'cartmate' ) !== 0 ) return;

        $plugin_main_file = dirname( dirname( dirname( __FILE__ ) ) ) . '/cartmate.php';
        $css_url = plugins_url( 'assets/css/cartmate-admin.css', $plugin_main_file );

        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( '[CartMate_Admin] Enqueue admin CSS: ' . $css_url );
        }

        wp_enqueue_style(
            'cartmate-admin',
            $css_url,
            array(),
            '1.0.0'
        );
    }

    public function handle_form_submission() {
        if ( ! isset( $_POST['cartmate_settings_nonce'] ) ) return;
        if ( ! current_user_can( 'manage_woocommerce' ) ) return;
        if ( ! wp_verify_nonce( $_POST['cartmate_settings_nonce'], 'cartmate_save_settings' ) ) return;

        $get_post = function( $key, $default = '' ) {
            return isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : $default;
        };

        // Determine current tab (so we can route specific save actions).
        $tab = $this->get_current_tab();

        /**
         * TAB: EMAIL (Email #1 options)
         */
        if ( $tab === 'email' ) {

            $email_1_enabled = (int) $get_post( 'cartmate_email_1_enabled', 1 );
            update_option( 'cartmate_email_1_enabled', $email_1_enabled ? 1 : 0 );

            $delay_minutes = intval( $get_post( 'cartmate_email_1_delay_minutes', 30 ) );
            if ( $delay_minutes < 0 ) $delay_minutes = 0;
            update_option( 'cartmate_email_1_delay_minutes', $delay_minutes );

            $email_subject = sanitize_text_field( $get_post( 'cartmate_email_1_subject', '' ) );
            update_option( 'cartmate_email_1_subject', $email_subject );

            $email_body = wp_kses_post( $get_post( 'cartmate_email_1_body', '' ) );
            update_option( 'cartmate_email_1_body', $email_body );

            add_settings_error( 'cartmate_messages', 'cartmate_settings_saved', __( 'Email settings saved.', 'cartmate' ), 'updated' );
            return;
        }

        /**
         * TAB: EMAIL FOLLOWUPS (DB-driven scheduled emails)
         */
        if ( $tab === 'email_followups' ) {
            $this->handle_followups_submission();
            return;
        }

        /**
         * TAB: SMS / ClickSend
         */
        if ( $tab === 'sms' ) {
            $sms_delay_minutes = intval( $get_post( 'cartmate_sms_followup_delay', 2880 ) );
            if ( $sms_delay_minutes < 0 ) $sms_delay_minutes = 0;
            update_option( 'cartmate_sms_followup_delay', $sms_delay_minutes );

            $clicksend_username = sanitize_text_field( $get_post( 'cartmate_clicksend_username', '' ) );
            $clicksend_api_key  = sanitize_text_field( $get_post( 'cartmate_clicksend_api_key', '' ) );
            $clicksend_sender   = sanitize_text_field( $get_post( 'cartmate_clicksend_sender', 'WPCartMate' ) );
            $sms_template       = wp_kses_post( $get_post( 'cartmate_sms_template', '' ) );
            $test_phone         = sanitize_text_field( $get_post( 'cartmate_test_phone', '' ) );

            update_option( 'cartmate_clicksend_username', $clicksend_username );
            update_option( 'cartmate_clicksend_api_key', $clicksend_api_key );
            update_option( 'cartmate_clicksend_sender', $clicksend_sender );
            update_option( 'cartmate_sms_template', $sms_template );
            update_option( 'cartmate_test_phone', $test_phone );

            if ( isset( $_POST['cartmate_send_test_sms'] ) ) {
                if ( ! class_exists( 'CartMate_SMS' ) ) {
                    require_once dirname( dirname( __FILE__ ) ) . '/class-cartmate-sms.php';
                }

                if ( ! empty( $test_phone ) && class_exists( 'CartMate_SMS' ) ) {
                    $result = CartMate_SMS::send_test_sms( $test_phone );
                    if ( is_wp_error( $result ) ) {
                        add_settings_error( 'cartmate_messages', 'cartmate_sms_test_error', sprintf( __( 'Test SMS failed: %s', 'cartmate' ), esc_html( $result->get_error_message() ) ), 'error' );
                    } else {
                        add_settings_error( 'cartmate_messages', 'cartmate_sms_test_success', __( 'Test SMS sent successfully.', 'cartmate' ), 'updated' );
                    }
                } else {
                    add_settings_error( 'cartmate_messages', 'cartmate_sms_test_missing_phone', __( 'Please enter a test phone number before sending a test SMS.', 'cartmate' ), 'error' );
                }
            }

            add_settings_error( 'cartmate_messages', 'cartmate_settings_saved', __( 'SMS settings saved.', 'cartmate' ), 'updated' );
            return;
        }

        /**
         * TAB: Notifications
         */
        if ( $tab === 'notifications' ) {
            $admin_email = sanitize_email( $get_post( 'cartmate_admin_email', '' ) );
            update_option( 'cartmate_admin_email', $admin_email );

            add_settings_error( 'cartmate_messages', 'cartmate_settings_saved', __( 'Admin email saved.', 'cartmate' ), 'updated' );
            return;
        }

        /**
         * TAB: License
         */
        if ( $tab === 'license' ) {
            $license_key = sanitize_text_field( $get_post( 'cartmate_license_key', '' ) );
            update_option( 'cartmate_license_key', $license_key );

            add_settings_error( 'cartmate_messages', 'cartmate_settings_saved', __( 'License saved.', 'cartmate' ), 'updated' );
            return;
        }

        add_settings_error( 'cartmate_messages', 'cartmate_settings_saved', __( 'WPCartMate settings saved.', 'cartmate' ), 'updated' );
    }

    protected function handle_followups_submission() {
        global $wpdb;

        $table = $wpdb->prefix . 'cartmate_email_sequences';

        // Ensure table exists (DB installer should create it, but we guard).
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) !== $table ) {
            add_settings_error( 'cartmate_messages', 'cartmate_followups_missing_table', __( 'Email follow-ups table is missing. Please re-activate the plugin to run install.', 'cartmate' ), 'error' );
            return;
        }

        // Actions: add, update, delete, toggle
        $action = isset($_POST['cartmate_followup_action']) ? sanitize_text_field(wp_unslash($_POST['cartmate_followup_action'])) : '';

        if ( $action === 'add' ) {
            $delay_days  = isset($_POST['delay_days']) ? (int) $_POST['delay_days'] : 1;
            $subject     = isset($_POST['subject']) ? sanitize_text_field(wp_unslash($_POST['subject'])) : '';
            $body        = isset($_POST['body']) ? wp_kses_post(wp_unslash($_POST['body'])) : '';
            $enabled     = isset($_POST['enabled']) ? 1 : 0;

            $max_sort = (int) $wpdb->get_var( "SELECT COALESCE(MAX(sort_order),0) FROM {$table}" );
            $sort_order = $max_sort + 1;

            $wpdb->insert(
                $table,
                array(
                    'enabled'    => $enabled,
                    'delay_days' => $delay_days,
                    'subject'    => $subject,
                    'body'       => $body,
                    'sort_order' => $sort_order,
                    'created_at' => time(),
                    'updated_at' => time(),
                ),
                array( '%d','%d','%s','%s','%d','%d','%d' )
            );

            add_settings_error( 'cartmate_messages', 'cartmate_followup_added', __( 'Follow-up email added.', 'cartmate' ), 'updated' );
            return;
        }

        if ( $action === 'update' ) {
            $id         = isset($_POST['id']) ? (int) $_POST['id'] : 0;
            $delay_days = isset($_POST['delay_days']) ? (int) $_POST['delay_days'] : 1;
            $subject    = isset($_POST['subject']) ? sanitize_text_field(wp_unslash($_POST['subject'])) : '';
            $body       = isset($_POST['body']) ? wp_kses_post(wp_unslash($_POST['body'])) : '';
            $enabled    = isset($_POST['enabled']) ? 1 : 0;

            if ( $id > 0 ) {
                $wpdb->update(
                    $table,
                    array(
                        'enabled'    => $enabled,
                        'delay_days' => $delay_days,
                        'subject'    => $subject,
                        'body'       => $body,
                        'updated_at' => time(),
                    ),
                    array( 'id' => $id ),
                    array( '%d','%d','%s','%s','%d' ),
                    array( '%d' )
                );
                add_settings_error( 'cartmate_messages', 'cartmate_followup_updated', __( 'Follow-up email updated.', 'cartmate' ), 'updated' );
                return;
            }
        }

        if ( $action === 'delete' ) {
            $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
            if ( $id > 0 ) {
                $wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );
                add_settings_error( 'cartmate_messages', 'cartmate_followup_deleted', __( 'Follow-up email deleted.', 'cartmate' ), 'updated' );
                return;
            }
        }

        if ( $action === 'toggle' ) {
            $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
            if ( $id > 0 ) {
                $cur = (int) $wpdb->get_var( $wpdb->prepare( "SELECT enabled FROM {$table} WHERE id=%d", $id ) );
                $new = $cur ? 0 : 1;
                $wpdb->update(
                    $table,
                    array( 'enabled' => $new, 'updated_at' => time() ),
                    array( 'id' => $id ),
                    array( '%d','%d' ),
                    array( '%d' )
                );
                add_settings_error( 'cartmate_messages', 'cartmate_followup_toggled', __( 'Follow-up email toggled.', 'cartmate' ), 'updated' );
                return;
            }
        }

        add_settings_error( 'cartmate_messages', 'cartmate_followup_unknown', __( 'No follow-up action performed.', 'cartmate' ), 'error' );
    }

    protected function get_current_tab() {
        $page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : 'cartmate';

        switch ( $page ) {
            case 'cartmate-email':
                return 'email';
            case 'cartmate-email-followups':
                return 'email_followups';
            case 'cartmate-sms':
                return 'sms';
            case 'cartmate-notifications':
                return 'notifications';
            case 'cartmate-license':
                return 'license';
            case 'cartmate-status':
                return 'status';
            case 'cartmate':
            default:
                return 'dashboard';
        }
    }

    public function render_settings_page() {
        global $wpdb;

        $current_tab = $this->get_current_tab();

        // Email #1 options
        $email_1_enabled = (int) get_option( 'cartmate_email_1_enabled', 1 );
        $email_delay     = (int) get_option( 'cartmate_email_1_delay_minutes', 30 );
        $email_subject   = get_option( 'cartmate_email_1_subject', __( '{name}, you left something in your cart', 'cartmate' ) );
        $email_body      = get_option( 'cartmate_email_1_body', "Hi {name},\n\nLooks like you didn't finish your order.\n\nReturn here:\n{cart_url}\n\n– {site_name}" );

        // SMS options
        $sms_delay    = (int) get_option( 'cartmate_sms_followup_delay', 2880 );
        $cs_username  = get_option( 'cartmate_clicksend_username', '' );
        $cs_api_key   = get_option( 'cartmate_clicksend_api_key', '' );
        $cs_sender    = get_option( 'cartmate_clicksend_sender', 'WPCartMate' );
        $sms_template = get_option( 'cartmate_sms_template', __( "Hi {name}, your cart is waiting at {site_name}. Finish here: {cart_url}", 'cartmate' ) );
        $test_phone   = get_option( 'cartmate_test_phone', '' );

        // Notifications
        $admin_email = get_option( 'cartmate_admin_email', get_option( 'admin_email' ) );

        // License
        $license_key = get_option( 'cartmate_license_key', '' );

        $is_pro = function_exists( 'cartmate_is_pro' ) ? cartmate_is_pro() : ! empty( $license_key );

        $tabs = array(
            'dashboard' => array('label' => __( 'Dashboard', 'cartmate' ), 'slug' => 'cartmate'),
            'email'     => array('label' => __( 'Email Reminder', 'cartmate' ), 'slug' => 'cartmate-email'),
            'email_followups' => array('label' => __( 'Scheduled Email Followups', 'cartmate' ), 'slug' => 'cartmate-email-followups'),
            'sms'       => array('label' => __( 'SMS Settings', 'cartmate' ), 'slug' => 'cartmate-sms'),
            'notifications' => array('label' => __( 'Admin Notifications', 'cartmate' ), 'slug' => 'cartmate-notifications'),
            'license'   => array('label' => __( 'License & Upgrades', 'cartmate' ), 'slug' => 'cartmate-license'),
            'status'    => array('label' => __( 'System Status', 'cartmate' ), 'slug' => 'cartmate-status'),
        );
        ?>
        <div class="wrap cartmate-wrap">
            <div class="cartmate-header">
                <div class="cartmate-header-left">
                    <div class="cartmate-logo-mark">
                        <span class="cartmate-logo-check">✓</span>
                    </div>
                    <div class="cartmate-header-text">
                        <h1 class="cartmate-title">WPCartMate</h1>
                        <p class="cartmate-subtitle"><?php esc_html_e( 'Email & SMS recovery for WooCommerce carts', 'cartmate' ); ?></p>
                    </div>
                </div>
                <div class="cartmate-header-right">
                    <?php if ( $is_pro ) : ?>
                        <span class="cartmate-badge cartmate-badge--pro"><?php esc_html_e( 'PRO ACTIVE', 'cartmate' ); ?></span>
                    <?php else : ?>
                        <span class="cartmate-badge cartmate-badge--free"><?php esc_html_e( 'FREE VERSION', 'cartmate' ); ?></span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="cartmate-banner">
                <div class="cartmate-banner-left">
                    <span class="cartmate-chip cartmate-chip--autopilot"><?php esc_html_e( 'Recover more carts on autopilot', 'cartmate' ); ?></span>
                    <h2 class="cartmate-banner-title"><?php esc_html_e( 'Start with a simple email, then automate follow-ups.', 'cartmate' ); ?></h2>
                    <p class="cartmate-banner-text"><?php esc_html_e( 'Configure Email #1 and add scheduled follow-up emails. Customers get nudged without you lifting a finger.', 'cartmate' ); ?></p>
                </div>
                <div class="cartmate-banner-right">
                    <a href="https://hustlemate.au" target="_blank" class="button cartmate-button-outline"><?php esc_html_e( 'See WPCartMate Pro plans', 'cartmate' ); ?></a>
                </div>
            </div>

            <nav class="cartmate-nav">
                <ul class="cartmate-nav__list">
                    <?php foreach ( $tabs as $tab_id => $tab ) :
                        $is_active = ( $tab_id === $current_tab );
                        $url = admin_url( 'admin.php?page=' . $tab['slug'] );
                        ?>
                        <li class="cartmate-nav__item <?php echo $is_active ? 'cartmate-nav__item--active' : ''; ?>">
                            <a href="<?php echo esc_url( $url ); ?>" class="cartmate-nav__link"><?php echo esc_html( $tab['label'] ); ?></a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </nav>

            <?php settings_errors( 'cartmate_messages' ); ?>

            <form method="post" action="">
                <?php wp_nonce_field( 'cartmate_save_settings', 'cartmate_settings_nonce' ); ?>

                <?php
                switch ( $current_tab ) {
                    case 'email':
                        $this->render_tab_email_1( $email_1_enabled, $email_delay, $email_subject, $email_body );
                        break;

                    case 'email_followups':
                        $this->render_tab_email_followups();
                        break;

                    case 'sms':
                        $this->render_tab_sms( $sms_delay, $cs_username, $cs_api_key, $cs_sender, $sms_template, $test_phone );
                        break;

                    case 'notifications':
                        $this->render_tab_notifications( $admin_email );
                        break;

                    case 'license':
                        $this->render_tab_license( $license_key, $is_pro );
                        break;

                    case 'status':
                        $this->render_tab_status();
                        break;

                    case 'dashboard':
                    default:
                        $this->render_tab_dashboard( $email_delay, $sms_delay, $is_pro );
                        break;
                }
                ?>
            </form>
        </div>
        <?php
    }

    protected function render_tab_dashboard( $email_delay, $sms_delay, $is_pro ) {
        ?>
        <div class="cartmate-grid">
            <div class="cartmate-card">
                <h2 class="cartmate-card-title"><?php esc_html_e( 'Quick overview', 'cartmate' ); ?></h2>
                <p class="cartmate-card-description"><?php esc_html_e( 'Here’s how WPCartMate is set up on your store right now.', 'cartmate' ); ?></p>
                <ul class="cartmate-metrics">
                    <li class="cartmate-metrics__item"><span class="cartmate-metrics__label"><?php esc_html_e( 'Email #1 delay', 'cartmate' ); ?></span><span class="cartmate-metrics__value"><?php echo esc_html( $email_delay ); ?> <?php esc_html_e( 'min', 'cartmate' ); ?></span></li>
                    <li class="cartmate-metrics__item"><span class="cartmate-metrics__label"><?php esc_html_e( 'SMS follow-up delay', 'cartmate' ); ?></span><span class="cartmate-metrics__value"><?php echo esc_html( $sms_delay ); ?> <?php esc_html_e( 'min', 'cartmate' ); ?></span></li>
                    <li class="cartmate-metrics__item"><span class="cartmate-metrics__label"><?php esc_html_e( 'License mode', 'cartmate' ); ?></span><span class="cartmate-metrics__value"><?php echo $is_pro ? esc_html__( 'Pro active', 'cartmate' ) : esc_html__( 'Free mode', 'cartmate' ); ?></span></li>
                </ul>
                <p class="cartmate-card-footer"><?php esc_html_e( 'Use the tabs above to adjust your sequences.', 'cartmate' ); ?></p>
            </div>

            <div class="cartmate-card">
                <h2 class="cartmate-card-title"><?php esc_html_e( 'Recommended next steps', 'cartmate' ); ?></h2>
                <ol class="cartmate-steps">
                    <li><?php esc_html_e( 'Set Email #1 to match your tone.', 'cartmate' ); ?></li>
                    <li><?php esc_html_e( 'Add 2–5 scheduled follow-ups (days after Email #1).', 'cartmate' ); ?></li>
                    <li><?php esc_html_e( 'Connect ClickSend and send a test SMS.', 'cartmate' ); ?></li>
                </ol>
                <p class="cartmate-card-footer"><?php esc_html_e( 'Next we’ll add WhatsApp in Pro.', 'cartmate' ); ?></p>
            </div>
        </div>
        <?php
    }

    protected function render_tab_email_1( $enabled, $email_delay, $email_subject, $email_body ) {
        ?>
        <div class="cartmate-grid">
            <div class="cartmate-card">
                <h2 class="cartmate-card-title"><?php esc_html_e( 'Email #1 (first reminder)', 'cartmate' ); ?></h2>
                <p class="cartmate-card-description"><?php esc_html_e( 'This is the first email sent after a cart is abandoned.', 'cartmate' ); ?></p>

                <div class="cartmate-field">
                    <label>
                        <input type="checkbox" name="cartmate_email_1_enabled" value="1" <?php checked( $enabled, 1 ); ?> />
                        <?php esc_html_e( 'Enable Email #1', 'cartmate' ); ?>
                    </label>
                </div>

                <div class="cartmate-field">
                    <label for="cartmate_email_1_delay_minutes"><?php esc_html_e( 'Delay before Email #1 (minutes)', 'cartmate' ); ?></label>
                    <input type="number" min="0" id="cartmate_email_1_delay_minutes" name="cartmate_email_1_delay_minutes" value="<?php echo esc_attr( $email_delay ); ?>" class="cartmate-input cartmate-input--sm" />
                    <p class="description"><?php esc_html_e( 'How long after abandonment should Email #1 be sent?', 'cartmate' ); ?></p>
                </div>

                <div class="cartmate-field">
                    <label for="cartmate_email_1_subject"><?php esc_html_e( 'Subject', 'cartmate' ); ?></label>
                    <input type="text" id="cartmate_email_1_subject" name="cartmate_email_1_subject" value="<?php echo esc_attr( $email_subject ); ?>" class="cartmate-input" />
                </div>

                <div class="cartmate-field">
                    <label for="cartmate_email_1_body"><?php esc_html_e( 'Body', 'cartmate' ); ?></label>
                    <textarea id="cartmate_email_1_body" name="cartmate_email_1_body" rows="8" class="cartmate-textarea"><?php echo esc_textarea( $email_body ); ?></textarea>
                    <p class="description"><?php esc_html_e( 'Tokens: {name}, {site_name}, {cart_url}', 'cartmate' ); ?></p>
                </div>

                <button type="submit" class="button button-primary cartmate-button-primary"><?php esc_html_e( 'Save Email #1', 'cartmate' ); ?></button>
            </div>
        </div>
        <?php
    }

    protected function render_tab_email_followups() {
        global $wpdb;

        $table = $wpdb->prefix . 'cartmate_email_sequences';

        $rows = array();
        if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) ) === $table ) {
            $rows = $wpdb->get_results(
                "SELECT id, enabled, delay_days, subject, body, sort_order
                 FROM {$table}
                 ORDER BY sort_order ASC, id ASC",
                ARRAY_A
            );
        }
        ?>
        <div class="cartmate-grid">
            <div class="cartmate-card">
                <h2 class="cartmate-card-title"><?php esc_html_e( 'Scheduled Email Followups', 'cartmate' ); ?></h2>
                <p class="cartmate-card-description"><?php esc_html_e( 'Add up to 5 follow-up emails (scheduled in days after Email #1).', 'cartmate' ); ?></p>

                <div class="cartmate-card" style="margin-top:14px;">
                    <h3 class="cartmate-card-title" style="margin-top:0;"><?php esc_html_e( 'Add a new follow-up', 'cartmate' ); ?></h3>

                    <input type="hidden" name="cartmate_followup_action" value="add" />

                    <div class="cartmate-field">
                        <label>
                            <input type="checkbox" name="enabled" value="1" checked />
                            <?php esc_html_e( 'Enabled', 'cartmate' ); ?>
                        </label>
                    </div>

                    <div class="cartmate-field">
                        <label for="delay_days"><?php esc_html_e( 'Send after (days from Email #1)', 'cartmate' ); ?></label>
                        <input type="number" min="0" id="delay_days" name="delay_days" value="1" class="cartmate-input cartmate-input--sm" />
                    </div>

                    <div class="cartmate-field">
                        <label for="subject"><?php esc_html_e( 'Subject', 'cartmate' ); ?></label>
                        <input type="text" id="subject" name="subject" value="" class="cartmate-input" placeholder="Quick reminder: your cart is still waiting at {site_name}" />
                    </div>

                    <div class="cartmate-field">
                        <label for="body"><?php esc_html_e( 'Body', 'cartmate' ); ?></label>
                        <textarea id="body" name="body" rows="5" class="cartmate-textarea" placeholder="Hi {name},&#10;&#10;Just checking in — your cart is still saved.&#10;{cart_url}"></textarea>
                        <p class="description"><?php esc_html_e( 'Tokens: {name}, {site_name}, {cart_url}', 'cartmate' ); ?></p>
                    </div>

                    <button type="submit" class="button cartmate-button-secondary"><?php esc_html_e( 'Add follow-up', 'cartmate' ); ?></button>
                </div>

                <hr style="margin:18px 0;" />

                <h3 class="cartmate-card-title" style="margin-top:0;"><?php esc_html_e( 'Existing follow-ups', 'cartmate' ); ?></h3>

                <?php if ( empty( $rows ) ) : ?>
                    <p><?php esc_html_e( 'No follow-ups created yet. Add one above.', 'cartmate' ); ?></p>
                <?php else : ?>
                    <div style="overflow:auto;">
                        <table class="widefat striped" style="min-width: 860px;">
                            <thead>
                                <tr>
                                    <th><?php esc_html_e( 'Order', 'cartmate' ); ?></th>
                                    <th><?php esc_html_e( 'Enabled', 'cartmate' ); ?></th>
                                    <th><?php esc_html_e( 'Delay (days)', 'cartmate' ); ?></th>
                                    <th><?php esc_html_e( 'Subject', 'cartmate' ); ?></th>
                                    <th><?php esc_html_e( 'Actions', 'cartmate' ); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ( $rows as $r ) : ?>
                                <tr>
                                    <td><?php echo (int) $r['sort_order']; ?></td>
                                    <td><?php echo ((int)$r['enabled'] === 1) ? esc_html__('Yes','cartmate') : esc_html__('No','cartmate'); ?></td>
                                    <td><?php echo (int) $r['delay_days']; ?></td>
                                    <td><?php echo esc_html( $r['subject'] ); ?></td>
                                    <td>
                                        <button type="button" class="button" onclick="document.getElementById('cm-edit-<?php echo (int)$r['id']; ?>').style.display='block';"><?php esc_html_e('Edit','cartmate'); ?></button>
                                        <button type="submit" class="button" name="cartmate_followup_action" value="toggle" onclick="document.getElementById('cm-toggle-id').value='<?php echo (int)$r['id']; ?>';"><?php esc_html_e('Toggle','cartmate'); ?></button>
                                        <button type="submit" class="button button-link-delete" name="cartmate_followup_action" value="delete" onclick="if(!confirm('Delete this follow-up?')){return false;} document.getElementById('cm-delete-id').value='<?php echo (int)$r['id']; ?>';"><?php esc_html_e('Delete','cartmate'); ?></button>

                                        <div id="cm-edit-<?php echo (int)$r['id']; ?>" style="display:none; margin-top:12px; padding:12px; border:1px solid #ddd; border-radius:8px; background:#fff;">
                                            <h4 style="margin-top:0;"><?php esc_html_e('Edit follow-up','cartmate'); ?></h4>

                                            <input type="hidden" name="cartmate_followup_action" value="update" />
                                            <input type="hidden" name="id" value="<?php echo (int)$r['id']; ?>" />

                                            <div class="cartmate-field">
                                                <label>
                                                    <input type="checkbox" name="enabled" value="1" <?php checked( (int)$r['enabled'], 1 ); ?> />
                                                    <?php esc_html_e('Enabled','cartmate'); ?>
                                                </label>
                                            </div>

                                            <div class="cartmate-field">
                                                <label><?php esc_html_e('Delay (days from Email #1)','cartmate'); ?></label>
                                                <input type="number" min="0" name="delay_days" value="<?php echo esc_attr((int)$r['delay_days']); ?>" class="cartmate-input cartmate-input--sm" />
                                            </div>

                                            <div class="cartmate-field">
                                                <label><?php esc_html_e('Subject','cartmate'); ?></label>
                                                <input type="text" name="subject" value="<?php echo esc_attr($r['subject']); ?>" class="cartmate-input" />
                                            </div>

                                            <div class="cartmate-field">
                                                <label><?php esc_html_e('Body','cartmate'); ?></label>
                                                <textarea name="body" rows="5" class="cartmate-textarea"><?php echo esc_textarea($r['body']); ?></textarea>
                                            </div>

                                            <button type="submit" class="button cartmate-button-secondary"><?php esc_html_e('Save changes','cartmate'); ?></button>
                                            <button type="button" class="button" onclick="document.getElementById('cm-edit-<?php echo (int)$r['id']; ?>').style.display='none';"><?php esc_html_e('Close','cartmate'); ?></button>
                                        </div>

                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Hidden IDs for toggle/delete -->
                    <input type="hidden" id="cm-toggle-id" name="id" value="" />
                    <input type="hidden" id="cm-delete-id" name="id" value="" />
                <?php endif; ?>

                <p class="description" style="margin-top:14px;">
                    <?php esc_html_e( 'Follow-ups are evaluated by WP-Cron. They send only when the prior step has been sent (email_step_sent advances).', 'cartmate' ); ?>
                </p>
            </div>
        </div>
        <?php
    }

    protected function render_tab_sms( $sms_delay, $cs_username, $cs_api_key, $cs_sender, $sms_template, $test_phone ) {
        ?>
        <div class="cartmate-grid">
            <div class="cartmate-card">
                <h2 class="cartmate-card-title"><?php esc_html_e( 'SMS reminder (ClickSend)', 'cartmate' ); ?></h2>
                <p class="cartmate-card-description"><?php esc_html_e( 'Send a gentle SMS nudge a short time after your email to recover even more carts.', 'cartmate' ); ?></p>

                <div class="cartmate-field">
                    <label for="cartmate_sms_followup_delay"><?php esc_html_e( 'Follow-up delay after email (minutes)', 'cartmate' ); ?></label>
                    <input type="number" min="0" id="cartmate_sms_followup_delay" name="cartmate_sms_followup_delay" value="<?php echo esc_attr( $sms_delay ); ?>" class="cartmate-input cartmate-input--sm" />
                </div>

                <div class="cartmate-field">
                    <label for="cartmate_clicksend_username"><?php esc_html_e( 'ClickSend username', 'cartmate' ); ?></label>
                    <input type="text" id="cartmate_clicksend_username" name="cartmate_clicksend_username" value="<?php echo esc_attr( $cs_username ); ?>" class="cartmate-input" />
                </div>

                <div class="cartmate-field">
                    <label for="cartmate_clicksend_api_key"><?php esc_html_e( 'ClickSend API key', 'cartmate' ); ?></label>
                    <input type="text" id="cartmate_clicksend_api_key" name="cartmate_clicksend_api_key" value="<?php echo esc_attr( $cs_api_key ); ?>" class="cartmate-input" />
                </div>

                <div class="cartmate-field">
                    <label for="cartmate_clicksend_sender"><?php esc_html_e( 'Sender name', 'cartmate' ); ?></label>
                    <input type="text" id="cartmate_clicksend_sender" name="cartmate_clicksend_sender" value="<?php echo esc_attr( $cs_sender ); ?>" class="cartmate-input" />
                </div>

                <div class="cartmate-field">
                    <label for="cartmate_sms_template"><?php esc_html_e( 'SMS template', 'cartmate' ); ?></label>
                    <textarea id="cartmate_sms_template" name="cartmate_sms_template" rows="4" class="cartmate-textarea"><?php echo esc_textarea( $sms_template ); ?></textarea>
                </div>

                <div class="cartmate-field">
                    <label for="cartmate_test_phone"><?php esc_html_e( 'Test phone number', 'cartmate' ); ?></label>
                    <input type="text" id="cartmate_test_phone" name="cartmate_test_phone" value="<?php echo esc_attr( $test_phone ); ?>" class="cartmate-input cartmate-input--sm" />
                </div>

                <div class="cartmate-actions-row">
                    <button type="submit" class="button cartmate-button-secondary"><?php esc_html_e( 'Save SMS settings', 'cartmate' ); ?></button>
                    <button type="submit" name="cartmate_send_test_sms" value="1" class="button cartmate-button-outline"><?php esc_html_e( 'Send test SMS', 'cartmate' ); ?></button>
                </div>
            </div>
        </div>
        <?php
    }

    protected function render_tab_notifications( $admin_email ) {
        ?>
        <div class="cartmate-grid">
            <div class="cartmate-card cartmate-card--narrow">
                <h2 class="cartmate-card-title"><?php esc_html_e( 'Admin notifications', 'cartmate' ); ?></h2>
                <div class="cartmate-field">
                    <label for="cartmate_admin_email"><?php esc_html_e( 'Admin notification email', 'cartmate' ); ?></label>
                    <input type="email" id="cartmate_admin_email" name="cartmate_admin_email" value="<?php echo esc_attr( $admin_email ); ?>" class="cartmate-input" />
                </div>
                <button type="submit" class="button cartmate-button-secondary"><?php esc_html_e( 'Save admin email', 'cartmate' ); ?></button>
            </div>
        </div>
        <?php
    }

    protected function render_tab_license( $license_key, $is_pro ) {
        ?>
        <div class="cartmate-grid">
            <div class="cartmate-card cartmate-card--narrow">
                <h2 class="cartmate-card-title"><?php esc_html_e( 'License & upgrades', 'cartmate' ); ?></h2>
                <div class="cartmate-field">
                    <label for="cartmate_license_key"><?php esc_html_e( 'License key', 'cartmate' ); ?></label>
                    <input type="text" id="cartmate_license_key" name="cartmate_license_key" value="<?php echo esc_attr( $license_key ); ?>" class="cartmate-input" />
                </div>
                <button type="submit" class="button cartmate-button-secondary"><?php esc_html_e( 'Save license', 'cartmate' ); ?></button>
                <p class="cartmate-status-line">
                    <strong><?php esc_html_e( 'Status:', 'cartmate' ); ?></strong>
                    <?php echo $is_pro ? esc_html__( 'Pro active on this site.', 'cartmate' ) : esc_html__( 'Free version active.', 'cartmate' ); ?>
                </p>
            </div>
        </div>
        <?php
    }

    protected function render_tab_status() {
        ?>
        <div class="cartmate-grid">
            <div class="cartmate-card">
                <h2 class="cartmate-card-title"><?php esc_html_e( 'System status', 'cartmate' ); ?></h2>
                <ul class="cartmate-status-list">
                    <li><strong><?php esc_html_e( 'Cron:', 'cartmate' ); ?></strong> <?php esc_html_e( 'cartmate_process_abandoned_carts scheduled (see debug.log).', 'cartmate' ); ?></li>
                    <li><strong><?php esc_html_e( 'Capture mode:', 'cartmate' ); ?></strong> <?php esc_html_e( 'WooCommerce checkout capture hook (block-based checkout).', 'cartmate' ); ?></li>
                    <li><strong><?php esc_html_e( 'Email follow-ups:', 'cartmate' ); ?></strong> <?php esc_html_e( 'Uses cartmate_email_sequences table and email_step_sent tracking.', 'cartmate' ); ?></li>
                </ul>
            </div>
        </div>
        <?php
    }
}

endif;
